/* ============================================
   NOTIFICATION BELL — Library Management System
   Add to every page after auth.js:
   <script src="js/notification-bell.js"></script>
   ============================================ */

// ── Inject bell into top-header on every page ─────────────────
// Call initNotificationBell() after buildSidebar() in each page's JS.
// OR it auto-inits on DOMContentLoaded if this script is included.

document.addEventListener('DOMContentLoaded', () => {
    // Wait for sidebar/header to render
    setTimeout(initNotificationBell, 100);
});

function initNotificationBell() {
    const headerActions = document.querySelector('.header-actions');
    if (!headerActions || document.getElementById('notifBellBtn')) return;

    // Inject bell button before existing header actions content
    const bellHtml = `
    <div class="notif-bell-wrap" style="margin-right:4px;">
      <button id="notifBellBtn" class="btn btn-secondary"
        style="padding:8px 12px;border-radius:var(--border-radius-full);position:relative;"
        onclick="toggleNotifDropdown()" title="Notifications">
        🔔
        <span id="notifBadge" style="
          position:absolute;top:-4px;right:-4px;
          background:#e74c3c;color:#fff;
          font-size:0.6rem;font-weight:700;
          min-width:16px;height:16px;border-radius:999px;
          display:none;align-items:center;justify-content:center;padding:0 3px;">
        </span>
      </button>

      <!-- Dropdown panel -->
      <div id="notifDropdown" class="notif-dropdown" style="display:none;">
        <div class="notif-dropdown-header">
          <span class="notif-dropdown-title">Notifications</span>
          <div style="display:flex;gap:8px;">
            <button class="notif-action-btn" onclick="markAllReadBell()">✓ All read</button>
            <a href="Notifications.html" class="notif-action-btn">View all →</a>
          </div>
        </div>
        <div id="notifDropdownList" class="notif-dropdown-list">
          <div style="text-align:center;padding:24px;color:var(--text-muted);font-size:0.875rem;">
            Loading...
          </div>
        </div>
        <div class="notif-dropdown-footer">
          <a href="notifications.html?tab=preferences" onclick="openPrefsBell(event)" class="notif-action-btn">
            ⚙ Preferences
          </a>
        </div>
      </div>
    </div>
  `;

    headerActions.insertAdjacentHTML('afterbegin', bellHtml);
    fetchBellNotifications();

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.notif-bell-wrap')) {
            document.getElementById('notifDropdown')?.style &&
                (document.getElementById('notifDropdown').style.display = 'none');
        }
    });
}

// ── Toggle dropdown ───────────────────────────────────────────
function toggleNotifDropdown() {
    const dropdown = document.getElementById('notifDropdown');
    if (!dropdown) return;
    const isOpen = dropdown.style.display === 'block';
    dropdown.style.display = isOpen ? 'none' : 'block';
    if (!isOpen) fetchBellNotifications();
}

// ── Fetch notifications for bell dropdown ─────────────────────
async function fetchBellNotifications() {
    try {
        const data = await apiGet('/notifications');
        const notifications = (data.notifications || []).slice(0, 6); // Show latest 6
        const unreadCount = data.unreadCount || 0;

        renderBellList(notifications);
        updateBellCount(unreadCount);
    } catch (_) { /* silent */ }
}

function renderBellList(notifications) {
    const list = document.getElementById('notifDropdownList');
    if (!list) return;

    if (!notifications.length) {
        list.innerHTML = `
      <div style="text-align:center;padding:32px 16px;color:var(--text-muted);font-size:0.875rem;">
        🔔 No notifications
      </div>`;
        return;
    }

    list.innerHTML = notifications.map(n => {
        const isUnread = n.status !== 'READ';
        const icon = { DUE_DATE_REMINDER: '📅', FINE_ALERT: '💰', NEW_BOOK_ARRIVAL: '📚' }[n.type] || '🔔';
        const time = formatBellTime(n.createdAt);

        return `
      <div class="notif-bell-item ${isUnread ? 'unread' : ''}"
        onclick="markBellRead(${n.id}, this)">
        <span class="notif-bell-icon">${icon}</span>
        <div class="notif-bell-body">
          <div class="notif-bell-title">${escapeHtml(n.title)}</div>
          <div class="notif-bell-msg">${escapeHtml(n.message)}</div>
          <div class="notif-bell-time">${time}</div>
        </div>
        ${isUnread ? '<span class="notif-bell-dot"></span>' : ''}
      </div>
    `;
    }).join('');
}

// ── Mark single read from bell ────────────────────────────────
async function markBellRead(id, el) {
    if (!el.classList.contains('unread')) return;
    try {
        await apiPut(`/notifications/${id}/read`);
        el.classList.remove('unread');
        el.querySelector('.notif-bell-dot')?.remove();
        const badge = document.getElementById('notifBadge');
        if (badge) {
            const cur = parseInt(badge.textContent) || 0;
            updateBellCount(Math.max(0, cur - 1));
        }
    } catch (_) { }
}

// ── Mark all read from bell ───────────────────────────────────
async function markAllReadBell() {
    try {
        await apiPut('/notifications/read-all');
        document.querySelectorAll('.notif-bell-item').forEach(el => {
            el.classList.remove('unread');
            el.querySelector('.notif-bell-dot')?.remove();
        });
        updateBellCount(0);
        showToast('All notifications marked as read.', 'success');
    } catch (error) {
        showToast(error.message, 'error');
    }
}

function updateBellCount(count) {
    const badge = document.getElementById('notifBadge');
    if (!badge) return;
    badge.textContent = count > 99 ? '99+' : count;
    badge.style.display = count > 0 ? 'flex' : 'none';
}

function formatBellTime(dateStr) {
    if (!dateStr) return '';
    const diff = Math.floor((Date.now() - new Date(dateStr)) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

function openPrefsBell(e) {
    e.preventDefault();
    window.location.href = 'notifications.html';
}

// Poll for new notifications every 60 seconds
setInterval(fetchBellNotifications, 60000);